<?php
/**
 * @category  Task
 * @package   Task_Careers
 * @author    TaskInfo Team
 * @copyright 2022 Task (https://www.Taskinfo.net/)
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Task_CustomShipping', __DIR__);
